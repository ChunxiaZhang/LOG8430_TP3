package tp3.plugin.commands;

public class CommandResponse {
	private String response;
	
	public CommandResponse(String response){
		this.setResponse(response);
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}
	
}
