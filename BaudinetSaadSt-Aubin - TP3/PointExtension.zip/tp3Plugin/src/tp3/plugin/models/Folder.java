package tp3.plugin.models;

import javax.swing.tree.TreePath;

import org.eclipse.core.resources.IResource;

public class Folder extends Item {

	public Folder(IResource resource) {
		super(resource);
	}
	
}
