package tp3.plugin.models;

import org.eclipse.core.resources.IResource;

public class Fichier extends Item {

	public Fichier(IResource resource) {
		super(resource);
	}

	
}
