package tp3.plugin.models;

public interface Receiver {
	String getPath();	
	// Get class of object
	String getClassName();
}
